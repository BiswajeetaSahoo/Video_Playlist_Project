import React from "react";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showVideo: false
    };
  }

  handleVideo = () => {
    this.setState({
      showVideo: !this.state.showVideo
    });
  };

  render() {
    return (
      <div>
        <h1
          style={{
            color: "yellowgreen"
          }}
        >
          Biswajeeta's playlist
        </h1>

        <div
          onClick={this.handleVideo}
          style={{
            backgroundColor: "grey",
            display: "inline-block",
            color: "white",
            padding: 20,
            margin: 30,
            borderRadius: 5
          }} //outer bracket is for JavaScript
          //inner one is to make sure its a object
        >
          AURORA - Runaway
        </div>

        {this.state.showVideo == true && (
          //Here <span> is used as the parent for different components
          //Here iframe,button
          <span>
            <iframe
              style={{
                width: "100%",
                height: "100vh"
              }} //outer bracket is for JavaScript
              //inner one is to make sure its a object

              src="https://www.youtube.com/embed/d_HlPboLRL8"
              title="YouTube video player"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>

            <button
              onClick={this.handleVideo}
              style={{
                position: "absolute",
                left: 245,
                top: 127
              }} //outer bracket is for JavaScript
              //inner one is to make sure its a object
            >
              Back
            </button>
          </span>
        )}
      </div>
    );
  }
}
